package userinterface;

import java.awt.BorderLayout;
/** This applications displays a window with text, an image and some coloured shapes, of which some colours can be changed
 * by filling in some colour values and clicking 'Draw'.
 * @author Thijs Willems s2507838
 *
 */
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Assignment2GUI extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldR;
	private JTextField textFieldG;
	private JTextField textFieldB;
	private JButton btnDraw;
	private DrawingPanel PanelDraw;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Assignment2GUI frame = new Assignment2GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Assignment2GUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		PanelDraw = new DrawingPanel();
		
		JPanel PanelInput = new JPanel();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(PanelInput, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(PanelDraw, GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE)
					.addContainerGap()) //creates panels
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(PanelInput, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE)
						.addComponent(PanelDraw, GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE))
					.addContainerGap()) //creates panels
		);
		
		textFieldR = new JTextField();
		textFieldR.setColumns(10);
		
		textFieldG = new JTextField();
		textFieldG.setColumns(10);
		
		textFieldB = new JTextField();
		textFieldB.setColumns(10); //create tect fields
		
		JLabel lblR = new JLabel("R:");
		
		JLabel lblB = new JLabel("G:");
		
		JLabel lblNewLabel_4 = new JLabel("B:"); //adds labels
		
		btnDraw = new JButton("Draw");
		btnDraw.addActionListener(new ActionListener() { //listen for input on 'Draw' button
			public void actionPerformed(ActionEvent e) {
				String r = textFieldR.getText();
				if (!r.matches("\\d+")) { r="0"; textFieldR.setText(r);}
				System.out.println("Input value for red: "+r);
				String g = textFieldG.getText();
				if (!g.matches("\\d+")) { g="0"; textFieldG.setText(g);}
				System.out.println("Input value for green: "+g);
				String b = textFieldB.getText(); //get numbers from the text fields
				if (!b.matches("\\d+")) { b="0"; textFieldB.setText(b);} // if there isn't an integer found in the text field, replace this field with a 0
				System.out.println("Input value for blue: "+b);// print out the colour values
				int rValue = Integer.parseInt(r);
				int gValue = Integer.parseInt(g);
				int bValue = Integer.parseInt(b); //convert the values in the string to an integer
				PanelDraw.setColor(rValue, gValue, bValue); //set these integers to be the drawing colour
			}
		});
		
		JPanel panelText = new JPanel();
		GroupLayout gl_PanelInput = new GroupLayout(PanelInput);
		gl_PanelInput.setHorizontalGroup(
			gl_PanelInput.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_PanelInput.createSequentialGroup()
					.addGroup(gl_PanelInput.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_PanelInput.createSequentialGroup()
							.addContainerGap()
							.addComponent(btnDraw, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE))
						.addComponent(panelText, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_PanelInput.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblR, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_PanelInput.createSequentialGroup()
							.addContainerGap()
							.addComponent(textFieldR, GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE))
						.addGroup(gl_PanelInput.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblB, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_PanelInput.createSequentialGroup()
							.addContainerGap()
							.addComponent(textFieldG, GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE))
						.addGroup(gl_PanelInput.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_4, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_PanelInput.createSequentialGroup()
							.addContainerGap()
							.addComponent(textFieldB, GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_PanelInput.setVerticalGroup(
			gl_PanelInput.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_PanelInput.createSequentialGroup()
					.addGap(7)
					.addComponent(panelText, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblR)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textFieldR, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblB)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textFieldG, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblNewLabel_4)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textFieldB, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
					.addComponent(btnDraw)
					.addContainerGap())
		); //setting up the relatiosn between the different components
		
		JLabel lblText1 = new JLabel("Enter, R, G, B");
		
		JLabel lblText2 = new JLabel("colour values");
		
		JLabel lblText3 = new JLabel("(0-255):"); //setting the text for the different labels
		GroupLayout gl_panelText = new GroupLayout(panelText);
		gl_panelText.setHorizontalGroup(
			gl_panelText.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelText.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panelText.createParallelGroup(Alignment.LEADING)
						.addComponent(lblText1, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblText2, GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
						.addComponent(lblText3, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_panelText.setVerticalGroup(
			gl_panelText.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelText.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblText1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblText2)
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(lblText3)
					.addContainerGap()) //sets the layout for the small planel within the previous one (text)
		);
		panelText.setLayout(gl_panelText);
		PanelInput.setLayout(gl_PanelInput);
		PanelDraw.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		contentPane.setLayout(gl_contentPane); //sets the positions of the main panels
		
		getRootPane().setDefaultButton(btnDraw);
		//Sets the 'Draw' button to be the default button
		 
	}
}
