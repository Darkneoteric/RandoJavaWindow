package userinterface;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
//all the packets that have been used in the window are displayed here

public class DrawingPanel extends JPanel {
	Color drawColor = Color.black; //default drawing colour black
	BufferedImage image = new BufferedImage (10, 10, BufferedImage.TYPE_INT_RGB); //create variable image including a scale factor
	public DrawingPanel() {
		super();
	File file = new File("Images/BlueThing.jpg"); //find attached file
	try {
		image = ImageIO.read(file); //read the attached file
	} catch (Exception e) {
		System.err.println("Unable to read file"); //if the image cannot be found, display error message
		return;
	  }
	}
	public void setColor(int r, int g, int b) { //Define new colour with the filled in values
		drawColor = new Color( r % 256, g % 256, b % 256); //set to rgb values
		repaint(); //draw again because the color has been changed
	}

	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		// improve rendering by turning on Antialiasing:
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHints(new RenderingHints( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON ));
		setBackground(new Color( 150, 150, 150)); //set background
		g.setColor(drawColor); //set colourto selected colour
		g.drawRect(70, 60, 50, 150); //draw a rectangle with a location (first 2 values) and shape(last 2, wxh)
		g.setFont(new Font("Tahoma", Font.PLAIN, 30)); //set font and size of text
		Color purple = new Color(128,0,128); //define the colour 'purple'
		g.setColor(purple); //set colour to 'purple'
		g.drawString("Weeeee", 120, 30); //draw 'Weeeee' at a specific location
		g.setColor(drawColor); //set colour to the selected colour
		g.fillOval(200, 30, 100, 100); //fill an oval with a location (first 2 values) and size (last 2, circle)
		g.drawLine(70, 60, 120, 210); //draw one of the diagonal lines
		g.drawLine(120, 60, 70, 210); //draws the other diagonal line
		g.drawArc(62, 34, 67, 150, 40, 100); //draws the arc on top
		g.setColor(Color.red); //sets colour to red
		g.fillOval(230, 50, 10, 30);//fill an oval with a location (first 2 values) and size (last 2)(left eye)
		g.fillOval(260, 50, 10, 30);//fill an oval with a location (first 2 values) and size (last 2)(right eye)
		g.fillOval(240, 85, 20, 15);//fill an oval with a location (first 2 values) and size (last 2)(nose)
		if (image != null); //if the image doesn't retrieve an error
			g.drawImage(image, 200, 150, 75, 75, this); //then display this image at 0,0, with scale (75,75)
		}
}


